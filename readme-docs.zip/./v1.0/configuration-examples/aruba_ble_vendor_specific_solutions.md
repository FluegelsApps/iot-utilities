---
title: BLE vendor specific solutions
excerpt: BLE vendor specific solutions
---

# BLE vendor specific solutions
